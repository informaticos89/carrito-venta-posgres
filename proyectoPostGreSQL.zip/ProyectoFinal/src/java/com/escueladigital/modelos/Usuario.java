package com.escueladigital.modelos;

public class Usuario {
    public short id_usuario;
    public String usuario;
    public String nombre;
    public String clave;
    public short id_perfil;
    public String perfil;
}
