package com.escueladigital.modelos;

public class Producto {
    public short id_producto;
    public String nombre;
    public short cantidad;
    public short precio;
    public Usuario usuario;
}
