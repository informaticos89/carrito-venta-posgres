package com.escueladigital.modelos;

public class Tercero {
    public short id_tercero;
    public String identificacion;
    public String nombre;
    public String direccion;
    public String telefono;
}
